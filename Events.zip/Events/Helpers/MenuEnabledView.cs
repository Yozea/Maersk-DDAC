﻿namespace Events.Web.Helpers
{
    public enum MenuEnabledView
    {
        Other = 0,
        Default = 1,
        MyEvents = 2,
        AddEvent = 3,
    }
}